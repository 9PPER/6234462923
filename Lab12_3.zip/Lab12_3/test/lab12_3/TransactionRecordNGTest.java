/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author MM
 */
public class TransactionRecordNGTest {
    
    public TransactionRecordNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of getAcctNo method, of class TransactionRecord.
     */
    @Test
    public void testGetAcctNo() {
        System.out.println("getAcctNo");
        TransactionRecord instance = null;
        int expResult = 0;
        int result = instance.getAcctNo();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setAcctNo method, of class TransactionRecord.
     */
    @Test
    public void testSetAcctNo() {
        System.out.println("setAcctNo");
        int acctNo = 0;
        TransactionRecord instance = null;
        instance.setAcctNo(acctNo);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getBalance method, of class TransactionRecord.
     */
    @Test
    public void testGetBalance() {
        System.out.println("getBalance");
        TransactionRecord instance = null;
        double expResult = 0.0;
        double result = instance.getBalance();
        assertEquals(result, expResult, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setBalance method, of class TransactionRecord.
     */
    @Test
    public void testSetBalance() {
        System.out.println("setBalance");
        double balance = 0.0;
        TransactionRecord instance = null;
        instance.setBalance(balance);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTransCnt method, of class TransactionRecord.
     */
    @Test
    public void testGetTransCnt() {
        System.out.println("getTransCnt");
        TransactionRecord instance = null;
        int expResult = 0;
        int result = instance.getTransCnt();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTransCnt method, of class TransactionRecord.
     */
    @Test
    public void testSetTransCnt() {
        System.out.println("setTransCnt");
        int transCnt = 0;
        TransactionRecord instance = null;
        instance.setTransCnt(transCnt);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class TransactionRecord.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        TransactionRecord instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
