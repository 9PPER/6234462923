/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author MM
 */
public class TransactionRecordTest {
    
    public TransactionRecordTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getAcctNo method, of class TransactionRecord.
     */
    @Test
    public void testGetAcctNo() {
        System.out.println("getAcctNo");
        TransactionRecord instance = null;
        int expResult = 0;
        int result = instance.getAcctNo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setAcctNo method, of class TransactionRecord.
     */
    @Test
    public void testSetAcctNo() {
        System.out.println("setAcctNo");
        int acctNo = 0;
        TransactionRecord instance = null;
        instance.setAcctNo(acctNo);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getBalance method, of class TransactionRecord.
     */
    @Test
    public void testGetBalance() {
        System.out.println("getBalance");
        TransactionRecord instance = null;
        double expResult = 0.0;
        double result = instance.getBalance();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setBalance method, of class TransactionRecord.
     */
    @Test
    public void testSetBalance() {
        System.out.println("setBalance");
        double balance = 0.0;
        TransactionRecord instance = null;
        instance.setBalance(balance);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTransCnt method, of class TransactionRecord.
     */
    @Test
    public void testGetTransCnt() {
        System.out.println("getTransCnt");
        TransactionRecord instance = null;
        int expResult = 0;
        int result = instance.getTransCnt();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTransCnt method, of class TransactionRecord.
     */
    @Test
    public void testSetTransCnt() {
        System.out.println("setTransCnt");
        int transCnt = 0;
        TransactionRecord instance = null;
        instance.setTransCnt(transCnt);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class TransactionRecord.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        TransactionRecord instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
