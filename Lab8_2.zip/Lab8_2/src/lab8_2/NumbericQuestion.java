package lab8_2;
import static java.lang.Math.abs;
public class NumbericQuestion extends Question 
{
    public NumbericQuestion()
    {
        super();
    }
    public NumbericQuestion(String text)
    {
        super(text);
    }
    public boolean checkAnswer(String response)
    {
        double numberRes = Double.valueOf(response);
        double numberAns = Double.valueOf(super.getAnswer());
        return abs(numberRes-numberAns)<0.01;
    }        
}