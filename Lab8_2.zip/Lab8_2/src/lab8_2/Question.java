package lab8_2;
public class Question 
{
    private String text,answer;
    public Question() 
    {
        
    }
    public Question(String text) 
    {
        this.text = text;
    }
    public void setText(String text)
    {
        this.text = text;
    }
    public void setAnswer(String ans)
    {
        answer = ans;
    }
    public String getText()
    {
        return text;
    }
    public String getAnswer()
    {
        return answer;
    }
    public boolean checkAnswer(String response)
    {
        return answer.equals(response);
    }
    public void display() 
    {
        System.out.println(text);
    }
}
