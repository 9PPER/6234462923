package lab8_2;
import java.util.ArrayList;
public class ChoiceQuestion extends Question 
{
    ArrayList<String> choices =  new ArrayList<>();
    public ChoiceQuestion()
    {
        super();
    }
    public ChoiceQuestion(String text)
    {
        super(text);
    }
    public void addChoice(String choice, boolean correct)
    {
        choices.add(choice);
        if(correct)
        {
            super.setAnswer(choice);
        }
    }
    public void display()
    {
        super.display();
        for(int i=0;i<choices.size()-1;i++){
            System.out.println((i+1)+": "+choices.get(i));
        }
    }
    public boolean checkAnswer(String response)
    {
        String ans = super.getAnswer();
        int intRes = Integer.parseInt(response);
        return ans.equals(choices.get(intRes-1));
    }
}
