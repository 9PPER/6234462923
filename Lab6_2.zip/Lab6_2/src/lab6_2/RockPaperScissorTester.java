package lab6_2;

public class RockPaperScissorTester 
{
    public static void main(String[] args)
    {
        Game game = new Game();
        game.play();
    }
}
