package lab6_2;

import java.util.Scanner;
import java.util.Random;

public class Game 
{
    private int playerPoint;
    private int computerPoint;
    private String playerChoice;
    private String computerChoice;
    
    public void play()
    {
        while(Math.abs(playerPoint-computerPoint)<2)
        {
            Scanner playerIn = new Scanner(System.in);
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            String pChoice = playerIn.next();
            if((pChoice.equals("0"))||(pChoice.equals("1"))||(pChoice.equals("2")));
            {
                switch(pChoice)
                {
                    case "0": playerChoice = "ROCK"; break;
                    case "1": playerChoice = "PAPER"; break;
                    case "2": playerChoice = "SCISSORS"; break;
                }
                System.out.print("You enter: "+playerChoice+"\n");
                Random computerIn = new Random();
                int cChoice = computerIn.nextInt(3);
                
                switch(cChoice)
                {
                    case 0: computerChoice = "ROCK"; break;
                    case 1: computerChoice = "PAPER"; break;
                    case 2: computerChoice = "SCISSORS"; break;
                }
                System.out.print("Computer: "+computerChoice+"\n");
                
                if(playerChoice.equals(computerChoice))
                {
                    System.out.print("It's a tie."+"\n");
                }
                else
                {
                    if ((pChoice.equals("0")&&cChoice==2)||(pChoice.equals("1")&&cChoice==0)||(pChoice.equals("2")&&cChoice==1))
                    {
                        System.out.print("You win!"+"\n");
                        playerPoint++;
                    }
                    else
                    {
                        System.out.print("You lose!"+"\n");
                        computerPoint++;
                    }
                }
            }
        }
        System.out.print("---------------------------------------"+"\n");
        
        if(playerPoint<computerPoint)
        {
            System.out.print("Too bad! You lose."+"\n");
        }
        else
        {
            System.out.print("Congrats! You win."+"\n");
        }
        System.out.print("User score: "+playerPoint+"\n");
        System.out.print("Computer score: "+computerPoint+"\n");
    }
}
