package lab9_2;

public abstract class Taylor 
{
    private int k;
    private double x;
    
    public int factorial(int n)
    {
        int ans = 1;
        if(n==0)
        {
            ans=0;
        }
        else 
        {
            for(int i=1;i<=n;i++)
            {
            ans=ans*i;
            }
        }
        return ans;
    }
    
    public void setIter(int k)
    {
        this.k=k;
    }
    
    public int getIter()
    {
        return k;
    }
    
    public void setValue(double x)
    {
        this.x=x;
    }
    
    public double getValue()
    {
        return x;
    }
    
    public abstract void printValue();
    public abstract double getApprox();
}
