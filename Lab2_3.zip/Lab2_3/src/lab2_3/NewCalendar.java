package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class NewCalendar {
    
    public static void main(String[] args) {
        
        GregorianCalendar getDate = new GregorianCalendar();
        getDate.add(Calendar.DAY_OF_MONTH, 100);
        
        System.out.print(getDate.get(Calendar.DAY_OF_WEEK)); System.out.print(" ");
        System.out.print(getDate.get(Calendar.DAY_OF_MONTH)); System.out.print(" ");
        System.out.print(getDate.get(Calendar.MONTH)); System.out.print(" ");
        System.out.println(getDate.get(Calendar.YEAR));
        
        GregorianCalendar myBirthday = new GregorianCalendar(2000, Calendar.SEPTEMBER, 22);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        
        System.out.print(myBirthday.get(Calendar.DAY_OF_WEEK)); System.out.print(" ");
        System.out.print(myBirthday.get(Calendar.DAY_OF_MONTH)); System.out.print(" ");
        System.out.print(myBirthday.get(Calendar.MONTH)); System.out.print(" ");
        System.out.println(myBirthday.get(Calendar.YEAR));
     
    }
    
}
