package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class WordContain 
{
    public static void main(String[] args) 
    {
        File file = new File("wordlist.txt");
        Scanner fileScanner = null;
        ArrayList<String> wordList = new ArrayList<>();
        try 
        {
            fileScanner = new Scanner(file);
            while (fileScanner.hasNextLine()) 
            {
                String line = fileScanner.nextLine();
                wordList.add(line);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        finally 
        {
            if (fileScanner != null) 
            {
                fileScanner.close();
            }
        }
        Scanner userInput = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String stringInput = userInput.nextLine();
        String wordsNotContained = "";
        boolean containAll = true;
        String[] words = stringInput.split(" ");
        for (String word : words) 
        {
            if (!wordList.contains(word)) 
            {
                containAll = false;
                wordsNotContained += word;
                wordsNotContained += " ";
            }
        }
        System.out.println("Words not contained:");
        if (containAll) 
        {
            System.out.println("N/A");
        }
        else 
        {
            System.out.println(wordsNotContained);
        }
    }
}