package lab9_1;

public class PizzaSpecial extends Pizza 
{
    private String special;
    
    public PizzaSpecial(String n, double p, String s)
    {
        super(n,p);
        special = s;
    }

    @Override
    public String toString()
    {
        return super.toString() + " special : " + special;
    }
}
