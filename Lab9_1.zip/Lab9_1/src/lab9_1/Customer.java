package lab9_1;

public class Customer 
{
    private String name;
    private String tel;
    
    public Customer()
    {
    
    }
    
    public Customer(String n,String t)
    {
        name = n; 
        tel = t;
    }
    
    public double getDiscount()
    {
        return 0;
    }

    @Override
    public String toString()
    {
        return name + " tel : " + tel;
    }
}
