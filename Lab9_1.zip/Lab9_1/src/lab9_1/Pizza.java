package lab9_1;

public class Pizza 
{
    private String name;
    private double price;
    public Pizza()
    {
    
    }
    
    public Pizza(String n,double p)
    {
        name = n;
        price = p;
    }
    
    public double getPrice()
    {
        return price;
    }

    @Override
    public String toString()
    {
        return name + " price : " + price;
    }
}
