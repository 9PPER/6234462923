package lab9_1;

public class GoldCustomer extends Customer 
{
    private double discount;
    
    public GoldCustomer(String n,String t,double d)
    {
        super(n,t);
        discount = d;
    }
    
    @Override
    public double getDiscount()
    {
        return discount;
    }

    @Override
    public String toString()
    {
        return super.toString() + " discount : " + discount;
    }
}
