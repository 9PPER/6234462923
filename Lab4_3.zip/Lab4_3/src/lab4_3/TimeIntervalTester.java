package lab4_3;

import java.util.Scanner;

public class TimeIntervalTester 
{
    public static void main(String[] args)
    {
        Scanner startT = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int start = startT.nextInt();
        Scanner endT = new Scanner(System.in);
        System.out.print("Enter end time: ");
        int end = endT.nextInt();
        TimeInterval time = new TimeInterval(start,end);
        System.out.println(Math.abs(time.getHours())+" hours "+Math.abs(time.getMinutes())+" minutes ");
    }
}
