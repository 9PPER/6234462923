package lab4_3;

public class TimeInterval 
{
    private int startTime;
    private int endTime;
    
    public TimeInterval(int enterStart, int enterEnd)
    {
        startTime = enterStart;
        endTime = enterEnd;
    }
    public int getHours()
    {
        int hours = (startTime - endTime)/100;
        return hours;
    }
    public int getMinutes()
    {
        int minutes = startTime%100 - endTime%100;
        return minutes;
    }
    
}
