package lab5_1;

enum Days 
{
    SUNDAY("Sunday"),
    MONDAY("Monday"),
    TUESDAY("Tuesday"),
    WEDNESDAY("Wednesday"),
    THURSDAY("Thursday"),
    FRIDAY("Friday"),
    SATURDAY("Saturday");
        
    public String day;
    Days(String day)
    {
        this.day = day;
    }
}
public class Zeller 
{
    private int year;
    private int month;
    private int dayOfMonth;
    
    public Zeller(int year, int month, int dayOfmonth)
    {
        this.year = year;
        this.month = month;
        this.dayOfMonth = dayOfmonth;
    }
    public String getDayOfWeek()
    {
        int q = dayOfMonth;
        int m;
        switch(month)
        {
            case 1: m = 13; year = year--; break;
            case 2: m = 14; year = year--; break;
            default: m = month;
        }
        int j = year/100;
        int k = year%100;
        int h = (q+(26*(m+1)/10)+k+(k/4)+(j/4)+(5*j))%7;
        switch(h)
        {
            case 0: return Days.SATURDAY.day;
            case 1: return Days.SATURDAY.day;
            case 2: return Days.MONDAY.day;
            case 3: return Days.TUESDAY.day;
            case 4: return Days.WEDNESDAY.day;
            case 5: return Days.THURSDAY.day;
            case 6: return Days.FRIDAY.day;
            default: return "Error";
        }
    }
}
