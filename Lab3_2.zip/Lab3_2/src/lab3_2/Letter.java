package lab3_2;

public class Letter
{
    private String senderPart;
    private final String recieverName;
    public Letter(String from, String to) 
    {
        senderPart = from;
        recieverName = "Dear "+to+":"+"\n"+"\n";
    }
    public void addLine(String line)
    {
        senderPart = senderPart+line+"\n";
    }
    public String getText()
    {
        senderPart = senderPart+"\n"+"Sincerely,"+"\n"+"\n"+recieverName;
        return senderPart;
    }
    
}
