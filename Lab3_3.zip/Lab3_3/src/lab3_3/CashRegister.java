package lab3_3;

public class CashRegister 
{
    private double taxCash;
    private double noTax;
    private double balance;
    private double purchase;
    String giveChange;
    
    public CashRegister(double payment)
    {
        balance = payment;
    }

    public void recordTaxablePurchase(double taxPurchase)
    {
        taxCash = taxCash + taxPurchase;
    }
    public void recordPurchase(double noTaxPurchase)
    {
        noTax = noTax + noTaxPurchase;
    }
    public void getTotalTax()
    {
        purchase = taxCash + taxCash*7/100 + noTax;
    }
    public double giveChange()
    {
        double change = balance - purchase;
        taxCash = 0;
        noTax = 0;
        balance = 0;
        return change;
    }

}
