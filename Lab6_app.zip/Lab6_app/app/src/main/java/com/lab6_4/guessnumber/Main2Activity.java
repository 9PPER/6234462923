package com.lab6_4.guessnumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class Main2Activity extends AppCompatActivity {


    public int appNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Button button = (Button) findViewById(R.id.button2);

        Random random = new Random();
        appNumber = random.nextInt(100) + 1;

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guessing();
            }
        });
    }

    public void guessing() {
        EditText inputNumber = (EditText) findViewById(R.id.numberInput);
        int number = Integer.parseInt(inputNumber.getText().toString());
        TextView textview = (TextView) findViewById(R.id.textView);
        if (number > appNumber) {
            textview.setText("Your guess is too high");
        } else if (number < appNumber) {
            textview.setText("Your guess is too low");
        } else {
            openActivity3();
        }

    }

    public void openActivity3() {
        Intent intent = new Intent(this, Main3Activity.class);
        startActivity(intent);
    }
}
