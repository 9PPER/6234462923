package lab7_1;

import java.util.ArrayList;  
import java.util.Arrays;

public class Purse 
{
    public ArrayList<String> purse = new ArrayList<>();
    public void addCoin(String coinName)
    {
        purse.add(coinName);
    } 
    public String toString()
    {
        return "Purse" + purse.toString();
    }
    public ArrayList<String> reverse()
    {
        ArrayList<String> revPurse = new ArrayList<>();
        for(int i = purse.size()-1; i>=0; i--)
        {
            revPurse.add(purse.get(i));
        }
        return revPurse;
    }
    public void transfer(Purse other)
    {
        while(purse.size()>0)
        {
            other.purse.add(purse.get(0));
            purse.remove(0);
        }
    }
    
    public boolean sameContents(Purse other)
    {
        if (purse.size()!=other.purse.size())
        {
            return false;
        }
        for(int i=0;i<purse.size();i++)
        {
            if (!purse.get(i).equals(other.purse.get(i)))
            {
                return false;
            }
        }
        return true;
    }
    public boolean sameCoins(Purse other)
    {
        int[] type = {0,0,0,0};
        int[] other_type = {0,0,0,0};
        if (purse.size()!=other.purse.size())
        {
            return false;
        }
        for(int i=0;i<purse.size();i++)
        {
            String face = this.purse.get(i);
            switch(face)
            {
                case "Penny":
                    type[0]+=1;
                    break;
                case "Nickel":
                    type[1]+=1;
                    break;
                case "Dime":
                    type[2]+=1;
                    break;
                case "Quarter":
                    type[3]+=1;
                    break;
            }     
        }
        for(int i=0;i<purse.size();i++)
        {
            String face = other.purse.get(i);
            switch(face)
            {
                case "Penny":
                    other_type[0]+=1;
                    break;
                case "Nickel":
                    other_type[1]+=1;
                    break;
                case "Dime":
                    other_type[2]+=1;
                    break;
                case "Quarter":
                    other_type[3]+=1;
                    break;
            }     
        }
        if (Arrays.equals(type,other_type))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
}
