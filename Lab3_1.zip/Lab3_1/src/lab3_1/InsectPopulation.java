package lab3_1;

public class InsectPopulation 
{

    private double insectNumber;

    public InsectPopulation(double pop)
    {
        insectNumber = pop; 
    }
    public void breed()
    {
        insectNumber = insectNumber*2;
    }
    public void spray()
    {
        insectNumber = insectNumber*90/100;
    }
    public double getNumInsect()
    {
        return insectNumber;
    }
    
    
}
